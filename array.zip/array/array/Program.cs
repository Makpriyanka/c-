﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace array
{
    class Program
    {
        static void Main(string[] args)
        {
            //one dimen array
            string[] ars = { "volov", "bmw", "ford", "mazda" };
            foreach (string val in cars) 
            {
                Console.WriteLine(val);

            }
            //multi dimen array
            string[,]bike=new string[2,2]
            {
                {"HONDA","HERO"},
                {"SUZAKI","kTM"}
        };
            foreach(string val1 in bike)
            {
                Console.WriteLine(val1);
            }
            //jagged array
            int[][]arr=new int [2][];

                arr[0]=new int [4]{11,21,56,78};
                    arr[1]=new int[6]{12,61,37,41,59,63};
            {
            
                    for(int i=0;i<arr.Length;i++)
                   for(int j=0;j<arr[i].length;j++)
                    {
                        Console.WriteLine(arr[i][j]+"");
                    }
                }
            Console.Read();
        }
        } 

    }





            

            
    
        }
    }
}
